$(function(){
    $('#close_btn').click(function(){
        window.close();
    });
})