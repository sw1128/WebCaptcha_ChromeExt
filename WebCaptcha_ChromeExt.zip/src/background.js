const CONVERT = '识别验证码'

const menus = [
  CONVERT
]

chrome.runtime.onInstalled.addListener(() => {
  menus.forEach(menu => chrome.contextMenus.create({
    id: menu,
    title: menu,
    contexts: ['all']
  }))
})

chrome.contextMenus.onClicked.addListener((info) => {
  if(menus.includes(info.menuItemId)){
    sendMessage(info)
  }
})